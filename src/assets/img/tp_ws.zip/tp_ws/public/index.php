<?php
use Framework\Kernel\Kernel;
use Framework\Request\Request;

require '../vendor/autoload.php';

$kernel = new Kernel();
$response = $kernel->handleRequest(Request::fromGlobals());

$kernel->display($response);

