<?php

use App\Controller\Homepage;
use App\Controller\Product\Persist as PersistProduct;
use Framework\Routing\Route;

return [
    'routing' => [
        new Route('GET', '/', Homepage::class),
        new Route('POST', '/api/products', PersistProduct::class),
    ]
];
