<?php

// Config::get('APP_ENV');
return [
  'APP_ENV' => 'dev',
  'TEMPLATES_PATH' => dirname(__DIR__) . '/templates',
];
