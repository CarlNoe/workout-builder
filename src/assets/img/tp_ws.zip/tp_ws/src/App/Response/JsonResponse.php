<?php

namespace App\Response;

use Framework\Response\AbstractResponse;

class JsonResponse extends AbstractResponse
{
    public function __construct(protected object $entity) {}

    public static function json(object $entity): JsonResponse
    {
        return new self($entity);
    }

    public function render(): string
    {
        $data= [
            'title' => $this->entity->getTitle()
        ];

        return json_encode($data);
    }
}
