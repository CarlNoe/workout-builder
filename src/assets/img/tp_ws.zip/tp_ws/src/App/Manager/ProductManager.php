<?php

namespace App\Manager;

use App\Entity\Product;
use App\Repository\ProductRepository;
use Framework\Doctrine\EntityManager;

class ProductManager
{
    protected ProductRepository $productRepository;

    public function __construct()
    {
        $em = EntityManager::getInstance();

        /** @var ProductRepository $productRepository */
        $productRepository = $em->getRepository(Product::class);

        $this->productRepository = $productRepository;
    }

    public function persist(Product $product): Product
    {
        return $this->productRepository->persist($product);
    }
}
