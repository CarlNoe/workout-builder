<?php

namespace App\Entity;

use ReflectionClass;

abstract class AbstractEntity
{
    public function __construct(array $params = [])
    {
        foreach ($params as $propertyName => $propertyValue) {
            $propertyNameFormatted = str_replace('-', '', ucwords($propertyName, '-'));
            $propertyNameFormatted = lcfirst(str_replace('_', '', ucwords($propertyNameFormatted, '_')));

            $setterName = 'set' . ucfirst($propertyNameFormatted);
            if (method_exists($this, $setterName)) {
                $this->$setterName($propertyValue);
            } else {
                $reflectionClass = new ReflectionClass($this);
                if ($reflectionClass->hasProperty($propertyNameFormatted)) {
                    $reflectionProperty = $reflectionClass->getProperty($propertyNameFormatted);
                    $reflectionProperty->setAccessible(true);

                    $reflectionProperty->setValue($this, $propertyValue);
                }
            }
        }
    }
}
