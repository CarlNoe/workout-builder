<?php

namespace App\Controller;

class Homepage
{
  public function __invoke()
  {
      echo 'Hello World';die;
  }
}
