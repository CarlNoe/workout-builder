<?php

namespace App\Controller\Product;

use App\Entity\Product;
use App\Manager\ProductManager;
use App\Response\JsonResponse;
use Framework\Request\Request;

class Persist
{
    public function __invoke()
    {
        $request = Request::fromGlobals();
        $accept = $request->getHeader('accept')[0] ?? 'application/json';

        $data = $_POST;

        $product = new Product($data);

        $productManager = new ProductManager();
        $product = $productManager->persist($product);

        switch ($accept) {
            case 'text/xml':

                break;
            case 'application/json':
            default: 
               return JsonResponse::json($product); 
                break;
        }
    }
}
