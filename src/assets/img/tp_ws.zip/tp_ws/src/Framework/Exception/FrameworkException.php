<?php

namespace Framework\Exception;

use Exception;

class FrameworkException extends Exception
{
}
