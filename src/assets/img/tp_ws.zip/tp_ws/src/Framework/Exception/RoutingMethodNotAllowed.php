<?php

namespace Framework\Exception;

use Exception;

class RoutingMethodNotAllowed extends Exception
{
}
