<?php

namespace Framework\Exception;

use Exception;

class RouteNotFoundException extends Exception
{
}
