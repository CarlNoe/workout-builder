<?php

namespace Framework\Kernel;

use Framework\Response\AbstractResponse;
use Framework\Routing\Routing;
use Psr\Http\Message\ServerRequestInterface;

class Kernel
{
  protected Routing $routing;

  public function __construct()
  {
    $this->routing = Routing::init();
  }

  public function handleRequest(ServerRequestInterface $request)
  {
    return $this->routing->route($request);
  }

  public function display(AbstractResponse $response)
  {
      echo $response->render($response);
  }
}

