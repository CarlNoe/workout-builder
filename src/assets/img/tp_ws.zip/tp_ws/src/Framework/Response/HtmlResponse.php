<?php

namespace Framework\Response;

use Framework\Templating\TemplatingInterface;
use Framework\Templating\Twig;

class HtmlResponse extends AbstractResponse
{
  protected TemplatingInterface $templating;

  public function __construct(
    protected string $template,
    protected array $args = []
    ) {
      $this->templating = new Twig();
    }

    public function render(): string
    {
        return $this->templating->render($this);
    }

  public function getTemplate(): string
  {
      return $this->template;
  }

  public function getArgs(): array 
  {
      return $this->args;
  }
}
