<?php

namespace Framework\Response;

use Framework\Exception\FrameworkException;

abstract class AbstractResponse
{
  public static function buildWithController(string $controller, array $args): self
  {
    $controller = new $controller();

    if (!is_callable($controller)) {
      throw new FrameworkException('You controller is not a valid callable!');
    }

    return $controller($args);
  }

    abstract public function render(): string;
}
