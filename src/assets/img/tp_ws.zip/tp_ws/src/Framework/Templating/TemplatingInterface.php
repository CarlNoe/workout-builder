<?php

namespace Framework\Templating;

use Framework\Response\HtmlResponse;

interface TemplatingInterface
{
    public function render(HtmlResponse $response): string;
}
